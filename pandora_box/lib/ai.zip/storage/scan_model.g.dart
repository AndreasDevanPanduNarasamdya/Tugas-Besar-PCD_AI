// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'scan_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class ScanModelAdapter extends TypeAdapter<ScanModel> {
  @override
  final int typeId = 0;

  @override
  ScanModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ScanModel()
      ..modelId = fields[0] as String
      ..modelName = fields[1] as String
      ..timestamp = fields[2] as DateTime
      ..thumbnail = fields[3] as Uint8List
      ..baseMap = fields[4] as Uint8List
      ..normalMap = fields[5] as Uint8List
      ..pointCloud = fields[6] as Uint8List
      ..exportPath = fields[7] as String
      ..frameCount = fields[8] as int
      ..isMeshGenerated = fields[9] as bool
      ..faceCount = fields[10] as int
      ..vertexCount = fields[11] as int
      ..edgeCount = fields[12] as int
      ..triangleCount = fields[13] as int
      ..fileSizeMb = fields[14] as double;
  }

  @override
  void write(BinaryWriter writer, ScanModel obj) {
    writer
      ..writeByte(15)
      ..writeByte(0)
      ..write(obj.modelId)
      ..writeByte(1)
      ..write(obj.modelName)
      ..writeByte(2)
      ..write(obj.timestamp)
      ..writeByte(3)
      ..write(obj.thumbnail)
      ..writeByte(4)
      ..write(obj.baseMap)
      ..writeByte(5)
      ..write(obj.normalMap)
      ..writeByte(6)
      ..write(obj.pointCloud)
      ..writeByte(7)
      ..write(obj.exportPath)
      ..writeByte(8)
      ..write(obj.frameCount)
      ..writeByte(9)
      ..write(obj.isMeshGenerated)
      ..writeByte(10)
      ..write(obj.faceCount)
      ..writeByte(11)
      ..write(obj.vertexCount)
      ..writeByte(12)
      ..write(obj.edgeCount)
      ..writeByte(13)
      ..write(obj.triangleCount)
      ..writeByte(14)
      ..write(obj.fileSizeMb);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ScanModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
