import 'dart:typed_data';
import 'dart:math' as math;
import 'package:vector_math/vector_math.dart';
import '../reconstruction/mesh_generator.dart';
// REMOVED: import '../reconstruction/point_cloud_builder.dart';
import '../config/env_config.dart';

// ── The only piece of PointCloudBuilder we kept! ──
class PointCloudPoint {
  final Vector3 position;
  final Vector3 color;
  final Vector3 normal;

  PointCloudPoint({
    required this.position,
    required this.color,
    required this.normal,
  });
}

class SpaceCarver {
  /// Full pipeline: 4 masks + 4 depth maps → MeshData
  ///
  /// [masks]          — 4 bool masks from ObjectSegmenter (foreground=true)
  /// [depthMaps]      — 4 Float32List depth maps from DepthAnything (0.0–1.0, near=high)
  /// [cameraPoses]    — 4 Matrix4 poses (0°, 90°, 180°, 270° around Y)
  /// [focalLength]    — camera focal length in pixels
  /// [cx],[cy]        — principal point (usually depthInputSize / 2)
  /// [maskWidth/Height] — depth map dimensions
  /// [voxelResolution]  — grid resolution (64=fast, 96=balanced, 128=detailed)
  /// [physicalSize]     — size of the voxel volume in meters
  static MeshData carveAndMesh({
    required List<List<bool>> masks,
    required List<Float32List> depthMaps,
    required List<Matrix4> cameraPoses,
    required double focalLength,
    required double cx,
    required double cy,
    int maskWidth = 518,
    int maskHeight = 518,
    int voxelResolution = 64,
    double physicalSize = 1.0,
    int tRes = 60,
    int pRes = 60,
  }) {
    // ── Step 1: Visual Hull carving ──────────────────────────────────────────
    final voxels = _carve(
      masks: masks,
      cameraPoses: cameraPoses,
      focalLength: focalLength,
      cx: cx,
      cy: cy,
      maskWidth: maskWidth,
      maskHeight: maskHeight,
      voxelResolution: voxelResolution,
      physicalSize: physicalSize,
    );

    if (voxels.isEmpty) {
      return MeshData(
        vertices: Float32List(0),
        indices: Uint32List(0),
        normals: Float32List(0),
        uvs: Float32List(0),
        colors: Float32List(0),
      );
    }

    // ── Step 2: Depth-weighted position refinement ───────────────────────────
    final refined = _refineWithDepth(
      voxels: voxels,
      depthMaps: depthMaps,
      cameraPoses: cameraPoses,
      focalLength: focalLength,
      cx: cx,
      cy: cy,
      maskWidth: maskWidth,
      maskHeight: maskHeight,
      physicalSize: physicalSize,
    );

    // ── Step 3: Estimate normals from voxel neighborhood ────────────────────
    final withNormals = _estimateNormals(refined);

    // ── Step 4: Mesh generation ──────────────────────────────────────────────
    return MeshGenerator().generate(withNormals, tRes, pRes);
  }

  // ── Private: Visual Hull voxel carving ──────────────────────────────────────

  static List<_Voxel> _carve({
    required List<List<bool>> masks,
    required List<Matrix4> cameraPoses,
    required double focalLength,
    required double cx,
    required double cy,
    required int maskWidth,
    required int maskHeight,
    required int voxelResolution,
    required double physicalSize,
  }) {
    final result = <_Voxel>[];
    final halfSize = physicalSize / 2.0;
    final stepSize = physicalSize / voxelResolution;

    final inversePoses =
        cameraPoses.map((p) => Matrix4.copy(p)..invert()).toList();

    for (int ix = 0; ix < voxelResolution; ix++) {
      final x = -halfSize + ix * stepSize;
      for (int iy = 0; iy < voxelResolution; iy++) {
        final y = -halfSize + iy * stepSize;
        for (int iz = 0; iz < voxelResolution; iz++) {
          final z = -halfSize + iz * stepSize;

          bool survives = true;

          for (int cam = 0; cam < masks.length; cam++) {
            final local = inversePoses[cam].transform(Vector4(x, y, z, 1.0));

            if (local.z <= 0.0) {
              survives = false;
              break;
            }

            final u = ((local.x * focalLength) / local.z + cx).round();
            final v = ((local.y * focalLength) / local.z + cy).round();

            if (u < 0 || u >= maskWidth || v < 0 || v >= maskHeight) {
              survives = false;
              break;
            }

            if (!masks[cam][v * maskWidth + u]) {
              survives = false;
              break;
            }
          }

          if (survives) {
            result.add(_Voxel(
              ix: ix,
              iy: iy,
              iz: iz,
              position: Vector3(x, y, z),
            ));
          }
        }
      }
    }

    return result;
  }

  // ── Private: Depth-weighted refinement ──────────────────────────────────────

  static List<_RefinedVoxel> _refineWithDepth({
    required List<_Voxel> voxels,
    required List<Float32List> depthMaps,
    required List<Matrix4> cameraPoses,
    required double focalLength,
    required double cx,
    required double cy,
    required int maskWidth,
    required int maskHeight,
    required double physicalSize,
  }) {
    final inversePoses =
        cameraPoses.map((p) => Matrix4.copy(p)..invert()).toList();

    const double nearPlane = 0.3;
    const double depthRange = 3.0;

    final result = <_RefinedVoxel>[];

    for (final voxel in voxels) {
      Vector3 refinedPos = voxel.position.clone();
      double totalWeight = 0.0;
      Vector3 weightedSum = Vector3.zero();

      for (int cam = 0; cam < depthMaps.length; cam++) {
        final local = inversePoses[cam].transform(
            Vector4(voxel.position.x, voxel.position.y, voxel.position.z, 1.0));

        if (local.z <= 0.0) continue;

        final u = ((local.x * focalLength) / local.z + cx).round();
        final v = ((local.y * focalLength) / local.z + cy).round();

        if (u < 0 || u >= maskWidth || v < 0 || v >= maskHeight) continue;

        final idx = v * maskWidth + u;
        if (idx >= depthMaps[cam].length) continue;

        final rawDepth = depthMaps[cam][idx];
        final metricDepth = nearPlane + (1.0 - rawDepth) * depthRange;

        final voxelDepth = local.z;
        final depthDiff = (voxelDepth - metricDepth).abs();

        const double sigma = 0.05;
        final weight = math.exp(-(depthDiff * depthDiff) / (2 * sigma * sigma));

        if (weight < 0.01) continue;

        final surfaceLocal = Vector3(
          (u - cx) * metricDepth / focalLength,
          (v - cy) * metricDepth / focalLength,
          metricDepth,
        );
        final surfaceWorld = cameraPoses[cam].transform3(surfaceLocal);

        weightedSum += surfaceWorld * weight;
        totalWeight += weight;
      }

      if (totalWeight > 0.0) {
        refinedPos = weightedSum / totalWeight;
      }

      result.add(_RefinedVoxel(
        position: refinedPos,
        confidence: totalWeight,
      ));
    }

    return result;
  }

  // ── Private: Normal estimation from voxel neighborhood ──────────────────────

  static List<PointCloudPoint> _estimateNormals(List<_RefinedVoxel> voxels) {
    if (voxels.isEmpty) return [];

    const double cellSize = 0.05;
    final Map<String, List<int>> grid = {};

    for (int i = 0; i < voxels.length; i++) {
      final p = voxels[i].position;
      final key = _cellKey(p, cellSize);
      grid.putIfAbsent(key, () => []).add(i);
    }

    final result = <PointCloudPoint>[];

    for (int i = 0; i < voxels.length; i++) {
      final p = voxels[i].position;
      final neighbors = <Vector3>[];

      final gx = (p.x / cellSize).floor();
      final gy = (p.y / cellSize).floor();
      final gz = (p.z / cellSize).floor();

      for (int dx = -1; dx <= 1; dx++) {
        for (int dy = -1; dy <= 1; dy++) {
          for (int dz = -1; dz <= 1; dz++) {
            final key = '${gx + dx},${gy + dy},${gz + dz}';
            final cell = grid[key];
            if (cell == null) continue;
            for (final j in cell) {
              if (j != i) neighbors.add(voxels[j].position);
            }
          }
        }
      }

      Vector3 normal;

      if (neighbors.length >= 3) {
        final centroid = neighbors.fold(Vector3.zero(), (acc, v) => acc + v) /
            neighbors.length.toDouble();

        double cxx = 0, cxy = 0, cxz = 0;
        double cyy = 0, cyz = 0, czz = 0;

        for (final n in neighbors) {
          final d = n - centroid;
          cxx += d.x * d.x;
          cxy += d.x * d.y;
          cxz += d.x * d.z;
          cyy += d.y * d.y;
          cyz += d.y * d.z;
          czz += d.z * d.z;
        }

        final axis1 = Vector3(cxx, cxy, cxz)..normalize();
        final axis2 = Vector3(cxy, cyy, cyz)..normalize();
        normal = axis1.cross(axis2);
        if (normal.length < 1e-6) normal = Vector3(0, 0, 1);
        normal.normalize();

        if (normal.dot(p) < 0) normal = -normal;
      } else {
        normal = -p.normalized();
        if (normal.length < 1e-6) normal = Vector3(0, 0, 1);
      }

      result.add(PointCloudPoint(
        position: p,
        color: Vector3(1, 1, 1),
        normal: normal,
      ));
    }

    return result;
  }

  static String _cellKey(Vector3 p, double cellSize) {
    final gx = (p.x / cellSize).floor();
    final gy = (p.y / cellSize).floor();
    final gz = (p.z / cellSize).floor();
    return '$gx,$gy,$gz';
  }
}

// ── Internal data classes ────────────────────────────────────────────────────

class _Voxel {
  final int ix, iy, iz;
  final Vector3 position;
  _Voxel({
    required this.ix,
    required this.iy,
    required this.iz,
    required this.position,
  });
}

class _RefinedVoxel {
  final Vector3 position;
  final double confidence;
  _RefinedVoxel({required this.position, required this.confidence});
}
